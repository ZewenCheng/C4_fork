import os, io, json, base64, time, threading, queue
import numpy as np
import requests
from PIL import Image
Image.MAX_IMAGE_PIXELS = None

BASE = "https://www.zsjsry.top/v1"
KEY  = os.environ["QWEN_API_KEY"]  # 从环境变量读取，勿硬编码
H    = {"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"}

def variants(path):
    img = Image.open(path).convert("RGB")
    img.thumbnail((768,768))
    flip = img.transpose(Image.FLIP_LEFT_RIGHT)
    w,h = img.size
    crop = img.crop((int(w*0.1),int(h*0.1),int(w*0.9),int(h*0.9)))
    return {"flip":flip, "crop":crop}

def to_item(img):
    buf = io.BytesIO(); img.save(buf,"JPEG",quality=85)
    return {"image":"data:image/jpeg;base64,"+base64.b64encode(buf.getvalue()).decode()}

def embed_batch(items, retries=4):
    for a in range(retries):
        try:
            r = requests.post(f"{BASE}/embeddings", headers=H,
                json={"model":"Qwen3-VL-Embedding-8B","input":items}, timeout=180)
            if r.status_code==200:
                return [d["embedding"] for d in r.json()["data"]]
            time.sleep(3*(a+1))
        except Exception:
            time.sleep(3*(a+1))
    return None

root = "dataset/赛题四"
tasks = []
for sub, prefix in [("训练集/轨道","train_rail"), ("初赛测试集/轨道","test_rail")]:
    d = f"{root}/{sub}"
    for f in sorted(os.listdir(d)):
        if f.lower().endswith((".jpg",".jpeg",".png")):
            tasks.append((f"{prefix}/{f}", os.path.join(d,f)))
print("images:", len(tasks), flush=True)

done, lock, q = {}, threading.Lock(), queue.Queue()
out_npz = "embeddings_rail_tta.npz"
if os.path.exists(out_npz):
    z = np.load(out_npz, allow_pickle=True)
    done = {k:v for k,v in zip(z["keys"], z["embs"])}
    print("resume:", len(done), flush=True)

todo = [t for t in tasks if f"flip::{t[0]}" not in done]
for i in range(0, len(todo), 2):
    q.put(todo[i:i+2])
t0=time.time()
def worker():
    while True:
        try: chunk = q.get_nowait()
        except queue.Empty: return
        items, ks = [], []
        for k, p in chunk:
            try:
                vs = variants(p)
                for vn, im in vs.items():
                    items.append(to_item(im)); ks.append(f"{vn}::{k}")
            except Exception: pass
        embs = embed_batch(items)
        if embs:
            with lock:
                for kk, e in zip(ks, embs): done[kk] = np.array(e, dtype=np.float16)
                n = len(done)
                if n % 80 < 4: print(f"{n} embs {time.time()-t0:.0f}s", flush=True)
ths=[threading.Thread(target=worker) for _ in range(4)]
[t.start() for t in ths]; [t.join() for t in ths]
keys_ = list(done.keys())
np.savez_compressed(out_npz, keys=np.array(keys_,dtype=object), embs=np.array([done[k] for k in keys_]))
print("saved", out_npz, len(keys_), flush=True)
