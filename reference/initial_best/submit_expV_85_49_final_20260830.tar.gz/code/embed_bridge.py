
import os, io, json, base64, time, threading, queue
import numpy as np
import requests
from PIL import Image
Image.MAX_IMAGE_PIXELS = None

BASE = "https://www.zsjsry.top/v1"
KEY  = os.environ["QWEN_API_KEY"]  # 从环境变量读取，勿硬编码
H    = {"Authorization": f"Bearer {KEY}", "Content-Type": "application/json"}

def img_item(path, size=768):
    img = Image.open(path).convert("RGB")
    img.thumbnail((size, size))
    buf = io.BytesIO(); img.save(buf, "JPEG", quality=85)
    return {"image": "data:image/jpeg;base64,"+base64.b64encode(buf.getvalue()).decode()}

def embed_batch(paths, retries=4):
    payload = {"model":"Qwen3-VL-Embedding-8B","input":[img_item(p) for p in paths]}
    for a in range(retries):
        try:
            r = requests.post(f"{BASE}/embeddings", headers=H, json=payload, timeout=180)
            if r.status_code == 200:
                return [d["embedding"] for d in r.json()["data"]]
            time.sleep(3*(a+1))
        except Exception:
            time.sleep(3*(a+1))
    return None

def run(tasks, out_npz, n_workers=4, bs=4):
    done, lock, q = {}, threading.Lock(), queue.Queue()
    # resume
    if os.path.exists(out_npz):
        z = np.load(out_npz, allow_pickle=True)
        done = {k: v for k, v in zip(z["keys"], z["embs"])}
        print(f"resume: {len(done)} already embedded", flush=True)
    todo = [(k, p) for k, p in tasks if k not in done]
    for i in range(0, len(todo), bs):
        q.put(todo[i:i+bs])
    n_total, t0 = len(todo), time.time()
    def worker():
        while True:
            try: chunk = q.get_nowait()
            except queue.Empty: return
            embs = embed_batch([p for _, p in chunk])
            with lock:
                if embs:
                    for (k, _), e in zip(chunk, embs):
                        done[k] = np.array(e, dtype=np.float16)
                n_done = sum(1 for k, _ in todo if k in done)
                if n_done % 40 < bs:
                    el = time.time()-t0
                    print(f"{n_done}/{n_total} {el:.0f}s", flush=True)
    ths = [threading.Thread(target=worker) for _ in range(n_workers)]
    [t.start() for t in ths]; [t.join() for t in ths]
    keys = list(done.keys())
    np.savez_compressed(out_npz, keys=np.array(keys, dtype=object),
                        embs=np.array([done[k] for k in keys]))
    print(f"saved {out_npz}: {len(keys)} embeddings", flush=True)
    missing = [k for k, _ in tasks if k not in done]
    print("missing:", len(missing), missing[:5], flush=True)

if __name__ == "__main__":
    root = "dataset/赛题四"
    tasks = []
    import os
    tr_root = f"{root}/训练集"
    for folder in sorted(os.listdir(tr_root)):
        p = os.path.join(tr_root, folder)
        if not os.path.isdir(p) or folder == "轨道": continue
        for f in sorted(os.listdir(p)):
            if f.lower().endswith((".jpg",".jpeg",".png")):
                tasks.append((f"train_bridge/{folder}/{f}", os.path.join(p, f)))
    te_root = f"{root}/初赛测试集"
    for folder in ["巫溪互通大桥","白沙溪2号桥"]:
        p = os.path.join(te_root, folder)
        for f in sorted(os.listdir(p)):
            if f.lower().endswith((".jpg",".jpeg",".png")):
                tasks.append((f"test_bridge/{folder}/{f}", os.path.join(p, f)))
    print("total tasks:", len(tasks), flush=True)
    run(tasks, "embeddings_bridge_768.npz", n_workers=4)
