
"""轨道 defectType kNN 标签转移 + 留一验证"""
import json, collections
import numpy as np

z = np.load("embeddings_rail.npz", allow_pickle=True)
keys, embs = list(z["keys"]), np.array(z["embs"], dtype=np.float32)
embs /= (np.linalg.norm(embs, axis=1, keepdims=True) + 1e-9)
idx = {k: i for i, k in enumerate(keys)}

gt = json.load(open("dataset/赛题四/训练集/汇总数据.json"))
rail_gt = {r["filename"]: r["defectType"] for r in gt if r["questionCategory"]=="轨道"}

train_keys = [k for k in keys if k.startswith("train_rail/") and k.split("/",1)[1] in rail_gt]
test_keys  = [k for k in keys if k.startswith("test_rail/")]
Xtr = embs[[idx[k] for k in train_keys]]
ytr = [rail_gt[k.split("/",1)[1]] for k in train_keys]
print(f"train {len(train_keys)}, test {len(test_keys)}")

def knn_predict(q, X, y, k=7, exclude=None, agg="weighted"):
    sims = X @ q
    if exclude is not None: sims[exclude] = -2
    top = np.argsort(-sims)[:k]
    votes = collections.defaultdict(float)
    for i in top:
        votes[y[i]] += float(sims[i]) if agg=="weighted" else 1.0
    return max(votes, key=votes.get), sims[top[0]]

# 留一验证（整标签组合作为类）
for k in [1,3,5,7,11]:
    hit = 0
    for i in range(len(train_keys)):
        pred, _ = knn_predict(Xtr[i], Xtr, ytr, k=k, exclude=i)
        hit += (pred == ytr[i])
    print(f"LOO k={k}: {hit/len(train_keys):.3f}")
