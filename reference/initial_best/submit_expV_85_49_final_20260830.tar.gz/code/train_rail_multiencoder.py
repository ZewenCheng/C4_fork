"""expP: 轨道 defectType = 5 编码器拼接 + LR
特征 = 官方Qwen3-VL(4096) + SigLIP2(1152) + DINOv2-L(1024) + EVA02(1024) + ConvNeXtV2(1536) = 8832 维
每个编码器取 orig/flip/centercrop 三视图, 各自 L2 归一化后相加再 L2。
C 由训练集内部 4 折 CV 选出 (C=20), 再用全部 800 张拟合, 预测 300 张测试图。
嵌套CV 估计: 0.6053 ± 0.0079 (对照官方嵌入单独 0.5816)
"""
import numpy as np, pandas as pd, os
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold

def l2(a): return a / np.linalg.norm(a, axis=-1, keepdims=True)

def three_view(feat_npz, order):
    f = np.load(feat_npz, allow_pickle=True)
    idx = {s: i for i, s in enumerate(list(f["stems"]))}
    o = [idx[s] for s in order]
    return l2(l2(f["orig"][o]) + l2(f["flip"][o]) + l2(f["crop"][o]))

TAGS = ["siglip2", "dinov2L", "eva02", "convnextv2"]
Xtr = np.hstack([OFFICIAL_TRAIN] + [three_view(f"feat_{t}.npz", tr_stems) for t in TAGS])
Xte = np.hstack([OFFICIAL_TEST]  + [three_view(f"feat_{t}_test.npz", te_stems) for t in TAGS])

inner = StratifiedKFold(n_splits=4, shuffle=True, random_state=100)
scores = {}
for C in (0.5, 1, 2, 5, 20):
    scores[C] = np.mean([(LogisticRegression(C=C, max_iter=2000)
                          .fit(Xtr[i], ytr[i]).predict(Xtr[j]) == ytr[j]).mean()
                         for i, j in inner.split(Xtr, ytr)])
bestC = max(scores, key=scores.get)
pred = LogisticRegression(C=bestC, max_iter=2000).fit(Xtr, ytr).predict(Xte)
