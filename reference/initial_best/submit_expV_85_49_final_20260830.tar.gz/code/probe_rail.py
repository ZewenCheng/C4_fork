"""轨道 defectType 监督分类头（冻结 Qwen3-VL 嵌入 + Logistic Regression）
三视图(orig/flip/crop) 768px 嵌入平均后 L2 归一化，多项逻辑回归 C=20。
5折CV: LR 59.1% vs kNN(k=7,T=0.2) 53.9%，+5.2pp。
"""
import numpy as np, json, collections
from sklearn.linear_model import LogisticRegression

def norm(a):
    a = np.asarray(a, dtype=np.float32)
    return a / (np.linalg.norm(a, axis=1, keepdims=True) + 1e-9)

o768 = dict(zip(*[list(np.load("embeddings_rail_768.npz", allow_pickle=True)[k]) for k in ("keys","embs")]))
tta  = dict(zip(*[list(np.load("embeddings_rail_tta.npz", allow_pickle=True)[k]) for k in ("keys","embs")]))
o768 = {k: v for k, v in zip(o768.keys(), norm(list(o768.values())))}
tta  = {k: v for k, v in zip(tta.keys(),  norm(list(tta.values())))}

gt = json.load(open("dataset/赛题四/训练集/汇总数据.json", encoding="utf-8"))
rail_gt = {r["filename"]: r["defectType"] for r in gt if r["questionCategory"]=="轨道"}
tri = lambda i: o768[i] + tta[f"flip::{i}"] + tta[f"crop::{i}"]

train_ids = sorted(k for k in o768 if k.startswith("train_rail/") and k.split("/",1)[1] in rail_gt)
test_ids  = sorted(k for k in o768 if k.startswith("test_rail/"))
X, y = norm([tri(i) for i in train_ids]), [rail_gt[i.split("/",1)[1]] for i in train_ids]
clf = LogisticRegression(C=20., max_iter=5000, n_jobs=-1).fit(X, y)
pred = clf.predict(norm([tri(i) for i in test_ids]))
json.dump({i.split("/",1)[1]: p for i, p in zip(test_ids, pred)},
          open("rail_lr_pred.json","w",encoding="utf-8"), ensure_ascii=False, indent=1)
