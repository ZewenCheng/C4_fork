#!/usr/bin/env python3
"""赛道四提交文件生成器 + schema 校验器（D0 基线版）
用法: python make_submission.py <dataset_root> <out.json> [--desc TEXT] [--wuxi-side gps|none]
"""
import json, os, re, sys, collections

FIELDS = ["questionCategory","bridgeName","defectLocation","filename",
          "defectType","defectDescription","ratingScale(1-5)"]

def make_row(cat, bridge, fn, dtype, desc, rating):
    return {"questionCategory":cat,"bridgeName":bridge,"defectLocation":"",
            "filename":fn,"defectType":dtype,"defectDescription":desc,
            "ratingScale(1-5)":rating}

def validate(rows, expected_n=1274):
    assert len(rows)==expected_n, f"行数 {len(rows)} != {expected_n}"
    fns=[r["filename"] for r in rows]
    assert len(set(fns))==len(fns), "filename 重复"
    for r in rows:
        assert list(r.keys())==FIELDS
        assert r["questionCategory"] in ("桥梁","轨道")
        assert r["defectLocation"]==""
        if r["questionCategory"]=="轨道":
            assert r["bridgeName"]=="" and r["defectDescription"]=="" and r["ratingScale(1-5)"]==""

def side_of(fn, default):
    m=re.match(r"^(左幅|右幅)", fn); return m.group(1) if m else default

def build(root, desc, wuxi_side_map=None):
    td=os.path.join(root,"初赛测试集"); rows=[]
    listdir=lambda d: sorted(f for f in os.listdir(os.path.join(td,d))
                             if f.lower().endswith((".jpg",".jpeg",".png")))
    for fn in listdir("轨道"):
        rows.append(make_row("轨道","",fn,"裂缝(混凝土裂缝)","",""))
    for fn in listdir("白沙溪2号桥"):
        rows.append(make_row("桥梁",f"白沙溪2号桥（{side_of(fn,'右幅')}）",fn,"完好",desc,""))
    for fn in listdir("巫溪互通大桥"):
        b = f"巫溪互通大桥（{wuxi_side_map[fn]}）" if wuxi_side_map else "巫溪互通大桥"
        rows.append(make_row("桥梁",b,fn,"完好",desc,""))
    return rows

if __name__=="__main__":
    root, out = sys.argv[1], sys.argv[2]
    desc = "路面完好，无明显病害"
    sm = None
    if "--wuxi-side" in sys.argv and sys.argv[sys.argv.index("--wuxi-side")+1]=="gps":
        sm = json.load(open("wuxi_gps_side_map.json",encoding="utf-8"))
    if "--desc" in sys.argv: desc = sys.argv[sys.argv.index("--desc")+1]
    rows = build(root, desc, sm)
    validate(rows)
    json.dump(rows, open(out,"w",encoding="utf-8"), ensure_ascii=False, indent=1)
    print("OK", out, len(rows))
