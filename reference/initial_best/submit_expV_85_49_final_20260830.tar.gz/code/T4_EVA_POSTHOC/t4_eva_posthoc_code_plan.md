# T4_EVA_POSTHOC Python Code Plan

- Approved decision: `track4_eva_posthoc_log_residual_20260829`
- Baseline: expQ 85.34 source package and full probability anchor.
- Main: fixed log-residual formula with `eps=1e-12`, `alpha=0.25`.
- Inputs: five sealed fold probability files and complete/metric hashes, locked OOF, source package, cleanup record.
- Required OOF: 19 changes, 12/2/5, Exact +10 rows, micro +1.1449889pp.
- Required test: exactly9 changed rows, minimum4/5 fold support, alpha±5% set invariance.
- Output: `results/T4_EVA_POSTHOC/experiments/round1/` containing result JSON, change log, probabilities, package, run summary and complete marker.
- Independent validator must recompute scalar log formula, all9 labels, source/result row differences and raw tar boundary.
- No test images, model weights, fitting, threshold search or row selection.
