#!/usr/bin/env python3
"""Independent scalar and tar validator for T4_EVA_POSTHOC."""

from __future__ import annotations

import hashlib
import json
import tarfile
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/T4_EVA_POSTHOC/experiments/round1"
SOURCE = ROOT / "Claude Science 精选归档_2026-08-23/07_安全提交包/submit_expQ_85.34_当前最佳.tar.gz"
PACKAGE = OUT / "submit_expV_eva_log_residual_posthoc.tar.gz"
RESULT = OUT / "result_expV_eva_log_residual_posthoc.json"
PROBS = OUT / "metrics/probabilities.npz"
CHANGE_LOG = OUT / "tables/change_log.csv"
REPORT = OUT / "independent_validation.json"
EPS = 1e-12
ALPHA = 0.25


def sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def softmax_row(values: np.ndarray) -> np.ndarray:
    values = values - np.max(values)
    exp = np.exp(values)
    return exp / np.sum(exp)


def read_result(package: Path):
    with tarfile.open(package, "r:gz") as archive:
        members = archive.getmembers()
        targets = [member for member in members if member.name == "result/result.json"]
        if len(targets) != 1:
            raise RuntimeError(f"Expected one result member in {package}")
        payload = archive.extractfile(targets[0]).read()
    return members, payload, json.loads(payload)


def metadata(member: tarfile.TarInfo):
    return {
        "name": member.name,
        "type": member.type,
        "mode": member.mode,
        "uid": member.uid,
        "gid": member.gid,
        "uname": member.uname,
        "gname": member.gname,
        "mtime": member.mtime,
        "linkname": member.linkname,
        "pax_headers": member.pax_headers,
    }


def main() -> None:
    if sha(PACKAGE) != "5d0f1187e3e834a731093f5d05041b581a45151e8e2c359faf81f10339711ec0":
        raise RuntimeError("Package hash mismatch")
    data = np.load(PROBS, allow_pickle=False)
    pq = data["full_expq_probability"].astype(np.float64)
    pb = data["fold_baseline_probability"].astype(np.float64)
    pc = data["fold_candidate_probability"].astype(np.float64)
    saved = data["final_probability"].astype(np.float64)
    if pq.shape != (300, 22) or pb.shape != (5, 300, 22) or pc.shape != (5, 300, 22):
        raise RuntimeError("Probability shapes changed")
    recomputed = np.empty_like(saved)
    for row in range(300):
        logits = np.log(np.clip(pq[row], EPS, 1.0))
        for cls in range(22):
            residuals = [
                np.log(max(float(pc[fold, row, cls]), EPS)) - np.log(max(float(pb[fold, row, cls]), EPS))
                for fold in range(5)
            ]
            logits[cls] += ALPHA * sum(residuals) / 5.0
        recomputed[row] = softmax_row(logits)
    max_formula_error = float(np.max(np.abs(recomputed - saved)))
    if max_formula_error > 2e-15 or not np.isfinite(saved).all() or np.min(saved) < 0 or np.max(saved) > 1 or np.max(np.abs(saved.sum(1) - 1)) > 1e-12:
        raise RuntimeError(f"Independent formula/probability gate failed: {max_formula_error}")
    anchor = np.argmax(pq, axis=1)
    final = np.argmax(saved, axis=1)
    changed = np.flatnonzero(anchor != final)
    if len(changed) != 9:
        raise RuntimeError("Independent changed-row count mismatch")
    for alpha in (0.2375, 0.25, 0.2625):
        candidate = np.empty_like(saved)
        for row in range(300):
            logits = np.log(np.clip(pq[row], EPS, 1.0))
            for cls in range(22):
                logits[cls] += alpha * sum(
                    np.log(max(float(pc[fold, row, cls]), EPS)) - np.log(max(float(pb[fold, row, cls]), EPS))
                    for fold in range(5)
                ) / 5.0
            candidate[row] = softmax_row(logits)
        if set(np.flatnonzero(np.argmax(candidate, axis=1) != anchor).tolist()) != set(changed.tolist()):
            raise RuntimeError("Independent alpha sensitivity mismatch")

    source_members, source_bytes, source_rows = read_result(SOURCE)
    new_members, new_bytes, new_rows = read_result(PACKAGE)
    if new_bytes != RESULT.read_bytes() or len(source_members) != 30 or len(new_members) != 30:
        raise RuntimeError("Result payload/member count mismatch")
    if [member.name for member in source_members] != [member.name for member in new_members]:
        raise RuntimeError("Tar member order/name mismatch")
    with tarfile.open(SOURCE, "r:gz") as source_tar, tarfile.open(PACKAGE, "r:gz") as new_tar:
        for source_member, new_member in zip(source_members, new_members):
            if metadata(source_member) != metadata(new_member):
                raise RuntimeError(f"Tar metadata changed: {source_member.name}")
            if source_member.name == "result/result.json":
                continue
            source_payload = source_tar.extractfile(source_member).read() if source_member.isfile() else b""
            new_payload = new_tar.extractfile(new_member).read() if new_member.isfile() else b""
            if source_payload != new_payload:
                raise RuntimeError(f"Non-result tar payload changed: {source_member.name}")
    if len(source_rows) != 1274 or len(new_rows) != 1274:
        raise RuntimeError("Result row count mismatch")
    differences = []
    bridge_unchanged = 0
    for old, new in zip(source_rows, new_rows):
        fields = [key for key in old if old[key] != new[key]]
        if old["questionCategory"] == "桥梁":
            bridge_unchanged += int(old == new)
        if fields:
            if old["questionCategory"] != "轨道" or fields != ["defectType"]:
                raise RuntimeError(f"Unexpected row difference: {fields}")
            differences.append((Path(old["filename"]).stem, old["defectType"], new["defectType"]))
    if bridge_unchanged != 974 or len(differences) != 9:
        raise RuntimeError("Bridge/change count mismatch")
    expected_stems = set(data["test_stems"][changed].astype(str).tolist())
    if {row[0] for row in differences} != expected_stems:
        raise RuntimeError("Result/probability changed stems mismatch")
    complete = json.loads((OUT / "complete.json").read_text(encoding="utf-8"))
    run_summary = json.loads((OUT / "run_summary.json").read_text(encoding="utf-8"))
    if complete["status"] != "PASS_READY_FOR_FINAL_SUBMISSION_CONFIRMATION" or complete["submission_performed"] is not False:
        raise RuntimeError("Completion safety status mismatch")
    if run_summary["approved_decision_id"] != "track4_eva_posthoc_log_residual_20260829":
        raise RuntimeError("Decision lineage mismatch")
    report = {
        "status": "INDEPENDENT_VALIDATION_PASS",
        "evidence_label": "POSTHOC_NEW_CANDIDATE",
        "package": str(PACKAGE),
        "package_sha256": sha(PACKAGE),
        "rows": 1274,
        "bridge_rows_unchanged": 974,
        "rail_defectType_changed": 9,
        "formula_max_abs_error": max_formula_error,
        "probability_min": float(saved.min()),
        "probability_max": float(saved.max()),
        "probability_row_sum_max_error": float(np.max(np.abs(saved.sum(1) - 1))),
        "alpha_sensitivity_identical_change_set": True,
        "tar_members": 30,
        "non_result_payloads_unchanged": 29,
        "changed_stems": sorted(expected_stems),
        "test_images_accessed": 0,
        "submission_performed": False,
    }
    REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
