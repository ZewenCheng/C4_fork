#!/usr/bin/env python3
"""Build the human-approved post-hoc EVA log-residual submission candidate."""

from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

import numpy as np


SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parents[1]
SOURCE_HELPER = PROJECT_ROOT / "experiments/rail_eva_residual_submit_20260824/aggregate_after_cleanup.py"
SOURCE_OUTPUT = PROJECT_ROOT / "experiments/rail_eva_residual_submit_20260824/outputs"
SOURCE_PACKAGE = PROJECT_ROOT / "Claude Science 精选归档_2026-08-23/07_安全提交包/submit_expQ_85.34_当前最佳.tar.gz"
SHRINK_OOF = PROJECT_ROOT / "experiments/rail_eva_shrink_residual_20260824/outputs/oof_probabilities.npz"
METHOD_CARD = PROJECT_ROOT / "methods/T4_EVA_POSTHOC/t4_eva_posthoc_method_card.md"
DATA_PROFILE = PROJECT_ROOT / "methods/T4_EVA_POSTHOC/data_profile.json"
PROBE = PROJECT_ROOT / "methods/T4_EVA_POSTHOC/probes/risk_probe_summary.json"
DECISIONS = PROJECT_ROOT / "methods/T4_EVA_POSTHOC/t4_eva_posthoc_decisions.jsonl"
CODE_PLAN = SCRIPT_DIR / "t4_eva_posthoc_code_plan.md"
OUTPUT = PROJECT_ROOT / "results/T4_EVA_POSTHOC/experiments/round1"
DECISION_ID = "track4_eva_posthoc_log_residual_20260829"
ALPHA = 0.25
EPS = 1e-12


def import_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


base = import_module(SOURCE_HELPER, "eva_log_residual_source")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_hash(payload: object) -> str:
    return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def artifact(path: Path) -> dict:
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)}


def atomic_json(path: Path, payload: object) -> None:
    base.atomic_bytes(path, (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def atomic_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    os.replace(temporary, path)


def softmax(logits: np.ndarray) -> np.ndarray:
    logits = np.asarray(logits, dtype=np.float64)
    logits = logits - logits.max(axis=1, keepdims=True)
    value = np.exp(logits)
    value /= value.sum(axis=1, keepdims=True)
    return value


def log_residual(anchor: np.ndarray, baseline: np.ndarray, candidate: np.ndarray, alpha: float) -> np.ndarray:
    log_delta = (np.log(np.clip(candidate, EPS, 1.0)) - np.log(np.clip(baseline, EPS, 1.0))).mean(axis=0)
    return softmax(np.log(np.clip(anchor, EPS, 1.0)) + alpha * log_delta)


def verify_decision_and_plan() -> dict:
    rows = [json.loads(line) for line in DECISIONS.read_text(encoding="utf-8").splitlines() if line.strip()]
    matches = [row for row in rows if row.get("decision_id") == DECISION_ID]
    if len(matches) != 1 or matches[0].get("choice") != "B" or matches[0].get("decided_by") != "human":
        raise RuntimeError("Human decision B is missing or ambiguous")
    return {name: artifact(path) for name, path in {
        "method_card": METHOD_CARD,
        "data_profile": DATA_PROFILE,
        "probe": PROBE,
        "decisions": DECISIONS,
        "code_plan": CODE_PLAN,
        "runner": Path(__file__).resolve(),
    }.items()}


def main() -> None:
    started = time.time()
    if OUTPUT.exists() and any(OUTPUT.iterdir()):
        raise RuntimeError("Formal output directory is not empty")
    method_sources = verify_decision_and_plan()
    legacy_sources = base.verify_locked_files()
    old_config = json.loads(base.OLD_CONFIG.read_text(encoding="utf-8"))
    old_signature = old_config.get("run_signature")
    if old_signature != "809a3439e5b53db513ad617bf4989168b51446d5aaf93ad4139ac83f80c747ce":
        raise RuntimeError("Original fold-generation signature changed")
    anchor_data = np.load(base.ANCHOR, allow_pickle=False)
    test_stems = anchor_data["test_stems"].astype(str)
    class_names = anchor_data["class_names"].astype(str)
    p_q = base.validate_probability("pQ", anchor_data["probability"], 300)
    template = base.load_template()
    known = {Path(row["filename"]).stem: row["defectType"] for row in template if row["questionCategory"] == "轨道"}
    anchor_idx = np.argmax(p_q, axis=1)
    if set(known) != set(test_stems) or not np.array_equal(class_names[anchor_idx], np.asarray([known[stem] for stem in test_stems])):
        raise RuntimeError("Source expQ package is not reproduced 300/300")

    locked, p_b_oof, p_c_oof, p_b_test, p_c_test, fold_records, missing_history = base.load_fold_artifacts(old_signature, test_stems, class_names)
    p_oof = softmax(
        np.log(np.clip(p_b_oof, EPS, 1.0))
        + ALPHA * (np.log(np.clip(p_c_oof, EPS, 1.0)) - np.log(np.clip(p_b_oof, EPS, 1.0)))
    )
    labels = locked["y_true"].astype(np.int64)
    baseline_oof_idx = np.argmax(p_b_oof, axis=1)
    candidate_oof_idx = np.argmax(p_oof, axis=1)
    changed_oof = baseline_oof_idx != candidate_oof_idx
    baseline_correct = baseline_oof_idx == labels
    candidate_correct = candidate_oof_idx == labels
    oof_counts = {
        "changed": int(changed_oof.sum()),
        "gains": int(np.sum(candidate_correct & ~baseline_correct)),
        "losses": int(np.sum(~candidate_correct & baseline_correct)),
        "wrong_to_wrong": int(np.sum(changed_oof & ~baseline_correct & ~candidate_correct)),
        "baseline_exact": int(baseline_correct.sum()),
        "candidate_exact": int(candidate_correct.sum()),
    }
    if oof_counts != {"changed": 19, "gains": 12, "losses": 2, "wrong_to_wrong": 5, "baseline_exact": 494, "candidate_exact": 504}:
        raise RuntimeError(f"Post-hoc OOF count gate mismatch: {oof_counts}")
    incidence = base.metric.class_incidence(class_names)
    baseline_metrics = base.metric.metric_bundle(incidence[baseline_oof_idx], incidence[labels], incidence)
    candidate_metrics = base.metric.metric_bundle(incidence[candidate_oof_idx], incidence[labels], incidence)
    micro_delta = candidate_metrics["atom_micro_f1"] - baseline_metrics["atom_micro_f1"]
    dice_delta = candidate_metrics["sample_dice"] - baseline_metrics["sample_dice"]
    exact_delta = candidate_metrics["exact_set_accuracy"] - baseline_metrics["exact_set_accuracy"]
    if abs(micro_delta - 0.011449889022641657) > 1e-12 or abs(dice_delta - 0.0125) > 1e-12 or abs(exact_delta - 0.0125) > 1e-12:
        raise RuntimeError("Post-hoc OOF metric gate mismatch")

    p_final = base.validate_probability("log_residual_final", log_residual(p_q, p_b_test, p_c_test, ALPHA), 300)
    final_idx = np.argmax(p_final, axis=1)
    changed_idx = np.flatnonzero(final_idx != anchor_idx)
    if len(changed_idx) != 9:
        raise RuntimeError(f"Expected exactly 9 fixed test changes, got {len(changed_idx)}")
    change_sets = []
    for alpha in (0.2375, 0.25, 0.2625):
        change_sets.append(set(np.flatnonzero(np.argmax(log_residual(p_q, p_b_test, p_c_test, alpha), axis=1) != anchor_idx).tolist()))
    if not (change_sets[0] == change_sets[1] == change_sets[2] == set(changed_idx.tolist())):
        raise RuntimeError("Alpha +/-5% change-set stability gate failed")
    raw_residual = p_c_test - p_b_test
    support = {}
    for index in changed_idx:
        old, new = int(anchor_idx[index]), int(final_idx[index])
        count = int(np.sum((raw_residual[:, index, new] - raw_residual[:, index, old]) > 0))
        if count < 4:
            raise RuntimeError(f"Changed row lacks fixed minimum 4/5 support: {test_stems[index]} {count}")
        support[int(index)] = count
    baseline_ensemble_agreement = float(np.mean(np.argmax(p_b_test.mean(axis=0), axis=1) == anchor_idx))
    if baseline_ensemble_agreement < 0.90:
        raise RuntimeError("Fold baseline/full anchor agreement below 90%")

    mapping = dict(zip(test_stems.tolist(), class_names[final_idx].tolist()))
    output_rows, changes = [], []
    margin = np.sort(p_final, axis=1)[:, -1] - np.sort(p_final, axis=1)[:, -2]
    for row in template:
        new_row = dict(row)
        if row["questionCategory"] == "轨道":
            stem = Path(row["filename"]).stem
            new_value = mapping[stem]
            if new_value != row["defectType"]:
                index = int(np.flatnonzero(test_stems == stem)[0])
                changes.append({
                    "stem": stem,
                    "filename": row["filename"],
                    "old_defectType": row["defectType"],
                    "new_defectType": new_value,
                    "fold_support": support[index],
                    "anchor_probability_old": float(p_q[index, anchor_idx[index]]),
                    "final_probability_new": float(p_final[index, final_idx[index]]),
                    "final_margin": float(margin[index]),
                })
                new_row["defectType"] = new_value
        output_rows.append(new_row)
    if len(changes) != 9:
        raise RuntimeError("Template change mapping mismatch")
    for old, new in zip(template, output_rows):
        if list(new) != base.FIELDS:
            raise RuntimeError("Result schema/order mismatch")
        differing = [key for key in old if old[key] != new[key]]
        if differing and differing != ["defectType"]:
            raise RuntimeError(f"Unexpected field change: {differing}")
    if sum(old == new for old, new in zip(template, output_rows) if old["questionCategory"] == "桥梁") != 974:
        raise RuntimeError("Bridge rows changed")

    OUTPUT.mkdir(parents=True, exist_ok=False)
    tables = OUTPUT / "tables"
    metrics = OUTPUT / "metrics"
    tables.mkdir(); metrics.mkdir()
    result_path = OUTPUT / "result_expV_eva_log_residual_posthoc.json"
    changes_path = tables / "change_log.csv"
    probabilities_path = metrics / "probabilities.npz"
    package_path = OUTPUT / "submit_expV_eva_log_residual_posthoc.tar.gz"
    staging = OUTPUT / ".submit_expV_eva_log_residual_posthoc.staging.tar.gz"
    result_bytes = json.dumps(output_rows, ensure_ascii=False, indent=1).encode("utf-8")
    base.atomic_bytes(result_path, result_bytes)
    atomic_csv(changes_path, changes, ["stem", "filename", "old_defectType", "new_defectType", "fold_support", "anchor_probability_old", "final_probability_new", "final_margin"])
    base.atomic_npz(
        probabilities_path,
        test_stems=test_stems,
        class_names=class_names,
        alpha=np.asarray(ALPHA),
        eps=np.asarray(EPS),
        full_expq_probability=p_q,
        fold_baseline_probability=p_b_test,
        fold_candidate_probability=p_c_test,
        final_probability=p_final,
        anchor_prediction=class_names[anchor_idx],
        final_prediction=class_names[final_idx],
    )
    base.safe.build_package(SOURCE_PACKAGE, staging, result_bytes)
    package_validation = base.safe.validate_package(SOURCE_PACKAGE, staging, output_rows, result_bytes)

    source_records = {**legacy_sources, **method_sources, "source_helper": artifact(SOURCE_HELPER)}
    run_payload = {
        "schema_version": 1,
        "question": "T4_EVA_POSTHOC",
        "round": "round1",
        "approved_decision_id": DECISION_ID,
        "evidence_label": "POSTHOC_NEW_CANDIDATE",
        "formula": "softmax(log(clip(pQ,eps,1)) + alpha * mean_fold(log(clip(pC,eps,1)) - log(clip(pB,eps,1))))",
        "alpha": ALPHA,
        "eps": EPS,
        "old_fold_generation_signature": old_signature,
        "source_records": source_records,
        "fold_records": fold_records,
        "historical_missing_checkpoints": missing_history,
        "oof_counts": oof_counts,
        "oof_metrics": {"baseline": baseline_metrics, "candidate": candidate_metrics, "micro_delta": micro_delta, "dice_delta": dice_delta, "exact_delta": exact_delta},
        "test_change_set_stable_alpha_plus_minus_5pct": True,
        "test_images_accessed": 0,
        "submission_generated": True,
    }
    run_signature = canonical_hash(run_payload)
    run_config_path = OUTPUT / "run_config.json"
    atomic_json(run_config_path, {**run_payload, "run_signature": run_signature})
    for record in source_records.values():
        path = Path(record["path"])
        if path.stat().st_size != record["bytes"] or sha256_file(path) != record["sha256"]:
            raise RuntimeError(f"Source changed during run: {path}")
    for record in fold_records.values():
        for key in ("features", "metrics", "complete"):
            path = Path(record[key]["path"])
            if path.stat().st_size != record[key]["bytes"] or sha256_file(path) != record[key]["sha256"]:
                raise RuntimeError(f"Fold source changed during run: {path}")
    os.replace(staging, package_path)

    metrics_path = metrics / "result.json"
    metrics_payload = {
        "status": "PASS_READY_FOR_FINAL_SUBMISSION_CONFIRMATION",
        "evidence_label": "POSTHOC_NEW_CANDIDATE",
        "original_eva_scientific_gate": "FAIL",
        "oof_counts": oof_counts,
        "baseline": baseline_metrics,
        "candidate": candidate_metrics,
        "micro_delta": micro_delta,
        "dice_delta": dice_delta,
        "exact_delta": exact_delta,
        "test_changed_rows": 9,
        "changes": changes,
        "baseline_ensemble_anchor_agreement": baseline_ensemble_agreement,
        "alpha_sensitivity": {"alphas": [0.2375, 0.25, 0.2625], "identical_change_set": True, "changed_rows": 9},
        "package_validation": {**package_validation, "bridge_rows_unchanged": 974, "rail_rows": 300, "rail_defectType_changed": 9},
        "test_images_accessed": 0,
        "submission_generated": True,
        "submission_performed": False,
    }
    atomic_json(metrics_path, metrics_payload)
    run_summary_path = OUTPUT / "run_summary.json"
    atomic_json(run_summary_path, {
        "schema_version": 1,
        "question": "T4_EVA_POSTHOC",
        "round": "round1",
        "implementation_target": "python",
        "approved_decision_id": DECISION_ID,
        "methods": [
            {"method_id": "M0_EXPQ", "role": "usable_baseline", "status": "success", "metrics_summary": baseline_metrics},
            {"method_id": "M1_LOG_RESIDUAL", "role": "main_candidate", "status": "success", "metrics_summary": candidate_metrics},
        ],
        "comparison": {"micro_delta": micro_delta, "dice_delta": dice_delta, "exact_delta": exact_delta, "test_changed_rows": 9},
        "run_signature": run_signature,
        "artifacts": {
            "result": artifact(result_path),
            "change_log": artifact(changes_path),
            "probabilities": artifact(probabilities_path),
            "package": artifact(package_path),
            "metrics": artifact(metrics_path),
            "run_config": artifact(run_config_path),
        },
        "execution_time_seconds": time.time() - started,
        "test_images_accessed": 0,
        "submission_performed": False,
    })
    complete_path = OUTPUT / "complete.json"
    atomic_json(complete_path, {
        "status": "PASS_READY_FOR_FINAL_SUBMISSION_CONFIRMATION",
        "run_signature": run_signature,
        "run_summary": artifact(run_summary_path),
        "package": artifact(package_path),
        "submission_performed": False,
    })
    print(json.dumps({
        "status": "PASS_READY_FOR_FINAL_SUBMISSION_CONFIRMATION",
        "package": str(package_path),
        "package_sha256": sha256_file(package_path),
        "changed_rows": 9,
        "changes": [[item["stem"], item["old_defectType"], item["new_defectType"], item["fold_support"]] for item in changes],
        "submission_performed": False,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
